package com.zengshaoyi.plugindemo.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/18 09:58
 */
public class DynamicBroadcastB extends BroadcastReceiver {

    private static final String TAG = "DynamicBroadcastB";

    private static final String ACTION = "com.zengshaoyi.plugindemo.receiver.DynamicBroadcastB";

    public static  void registerBroadcastB(Context context){
        Log.d(TAG, "registerBroadcastB");
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION);
        DynamicBroadcastB receiver = new DynamicBroadcastB();
        context.getApplicationContext().registerReceiver(receiver, intentFilter);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "I am DynamicBroadcastB");
    }
}
