package com.zengshaoyi.plugindemo.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/18 09:57
 */
public class StaticBroadcastA extends BroadcastReceiver {

    private static final String TAG = "StaticBroadcastA";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "I am StaticBroadcastA");
        DynamicBroadcastB.registerBroadcastB(context);
    }


}
