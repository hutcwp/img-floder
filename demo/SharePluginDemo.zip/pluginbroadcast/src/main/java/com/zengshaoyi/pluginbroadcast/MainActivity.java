package com.zengshaoyi.pluginbroadcast;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    private static final String BROADCAST_ACTION_A = "com.zengshaoyi.plugindemo.receiver.StaticBroadcastA";

    private static final String BROADCAST_ACTION_B = "com.zengshaoyi.plugindemo.receiver.DynamicBroadcastB";

    private Button mButton1;

    private Button mButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButton1 = findViewById(R.id.button1);
        mButton2 = findViewById(R.id.button2);
        mButton1.setOnClickListener(this);
        mButton2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == mButton1){
            sendPluginStaticBroadcastA();
        }else if(v == mButton2){
            sendPluginDynamicBroadcastB();
        }
    }

    private void sendPluginStaticBroadcastA(){
        Log.d(TAG, "sendPluginBroadcast");
        Intent intent = new Intent();
        intent.setAction(BROADCAST_ACTION_A);
        sendBroadcast(intent);
    }

    private void sendPluginDynamicBroadcastB(){
        Log.d(TAG, "sendPluginBroadcast");
        Intent intent = new Intent();
        intent.setAction(BROADCAST_ACTION_B);
        sendBroadcast(intent);
    }
}
