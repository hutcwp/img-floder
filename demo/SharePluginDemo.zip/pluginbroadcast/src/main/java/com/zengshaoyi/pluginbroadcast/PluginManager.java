package com.zengshaoyi.pluginbroadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.pm.PackageParser;
import android.util.Log;

import java.io.File;

import dalvik.system.DexClassLoader;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/17 21:04
 */
public class PluginManager {

    private static final String TAG = "PluginManager";

    private File mNativeLibDir;

    private static class SingletonHolder {
        private static PluginManager sInstance = new PluginManager();
    }

    private PluginManager() {
    }

    public static PluginManager getInstance() {
        return SingletonHolder.sInstance;
    }

    public void init(Context appContext) {
        Log.d(TAG, "init");
        Systems.setContext(appContext);
        FileUtils.copyAssets2InternalFiles(appContext, "plugindemo.apk");
        File dir = appContext.getFilesDir();
        File pluginAPK = new File(dir, "plugindemo.apk");
        Log.d(TAG, "is file exsists:"+pluginAPK.exists());
        this.mNativeLibDir = appContext.getDir(Constants.NATIVE_DIR, Context.MODE_PRIVATE);
        loadApk(appContext, pluginAPK, mNativeLibDir, appContext.getClassLoader());
        // 解析 plugin
        try {
            PackageParser.Package pluginPackage = PackageParserCompat.parsePackage(appContext, pluginAPK, PackageParser.PARSE_MUST_BE_APK);
            for (PackageParser.Activity receiver : pluginPackage.receivers) {
                Log.d(TAG, "receiver name:"+receiver.getComponentName().getClassName());
                BroadcastReceiver br = BroadcastReceiver.class.cast(appContext.getClassLoader().loadClass(receiver.getComponentName().getClassName()).newInstance());
                // 将静态广播接受者，转为动态注册
                for (PackageParser.ActivityIntentInfo aii : receiver.intents) {
                    Log.d(TAG, "registerReceiver br:"+ br + " intentFilter:"+aii);
                    appContext.registerReceiver(br, aii);
                }
            }
        } catch (PackageParser.PackageParserException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static ClassLoader loadApk(Context context, File apk, File libsDir, ClassLoader parent) {
        Log.d(TAG, "loadApk parent:"+parent);

        File dexOutputDir = context.getDir(Constants.OPTIMIZE_DIR, Context.MODE_PRIVATE);
        String dexOutputPath = dexOutputDir.getAbsolutePath();
        // 因为传入的父类 ClassLoader ，而且通过插入的方式传递到了parent类中，其实一直只会用到parent类处理类
        DexClassLoader loader = new DexClassLoader(apk.getAbsolutePath(), dexOutputPath, libsDir.getAbsolutePath(), parent);

        if (Constants.COMBINE_CLASSLOADER) {
            try {
                DexUtil.insertDex(loader);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return loader;
    }


}
