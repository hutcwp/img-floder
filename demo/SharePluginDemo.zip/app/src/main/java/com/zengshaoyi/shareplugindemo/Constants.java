package com.zengshaoyi.shareplugindemo;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/17 22:09
 */
public class Constants {
    public static final String KEY_IS_PLUGIN = "isPlugin";
    public static final String KEY_TARGET_PACKAGE = "target.package";
    public static final String KEY_TARGET_ACTIVITY = "target.activity";

}
