package com.zengshaoyi.shareplugindemo;

import android.app.Activity;
import android.app.Fragment;
import android.app.Instrumentation;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/17 21:07
 */
public class MyInstrumentation extends Instrumentation {

    private static final String TAG = "MyInstrumentation";

    private Instrumentation mBase;

    private PluginManager mPluginManager;

    public MyInstrumentation(Instrumentation pBase, PluginManager pPluginManager) {
        this.mBase = pBase;
        this.mPluginManager = pPluginManager;
    }

    public ActivityResult execStartActivity(
            Context who, IBinder contextThread, IBinder token, Activity target,
            Intent intent, int requestCode, Bundle options) {

        Log.d(TAG, "execStartActivity intent:" + intent);
        mPluginManager.makeIntentIfNeed(intent);

        ActivityResult result = realExecStartActivity(who, contextThread, token, target,
                intent, requestCode, options);

        return result;

    }

    private ActivityResult realExecStartActivity(
            Context who, IBinder contextThread, IBinder token, Activity target,
            Intent intent, int requestCode, Bundle options) {
        ActivityResult result = null;
        try {
            Class[] parameterTypes = {Context.class, IBinder.class, IBinder.class, Activity.class, Intent.class,
                    int.class, Bundle.class};
            result = (ActivityResult) ReflectUtil.invoke(Instrumentation.class, mBase,
                    "execStartActivity", parameterTypes,
                    who, contextThread, token, target, intent, requestCode, options);
        } catch (Exception e) {
            if (e.getCause() instanceof ActivityNotFoundException) {
                throw (ActivityNotFoundException) e.getCause();
            }
            e.printStackTrace();
        }

        return result;
    }

    public ActivityResult execStartActivity(
            Context who, IBinder contextThread, IBinder token, Fragment target,
            Intent intent, int requestCode, Bundle options) {

        Log.d(TAG, "execStartActivity intent:" + intent);
        mPluginManager.makeIntentIfNeed(intent);
        ActivityResult result = realExecStartActivity(who, contextThread, token, target,
                intent, requestCode, options);

        return result;

    }

    private ActivityResult realExecStartActivity(
            Context who, IBinder contextThread, IBinder token, Fragment target,
            Intent intent, int requestCode, Bundle options) {
        ActivityResult result = null;
        try {
            Class[] parameterTypes = {Context.class, IBinder.class, IBinder.class, Fragment.class, Intent.class,
                    int.class, Bundle.class};
            result = (ActivityResult) ReflectUtil.invoke(Instrumentation.class, mBase,
                    "execStartActivity", parameterTypes,
                    who, contextThread, token, target, intent, requestCode, options);
        } catch (Exception e) {
            if (e.getCause() instanceof ActivityNotFoundException) {
                throw (ActivityNotFoundException) e.getCause();
            }
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public Activity newActivity(ClassLoader cl, String className, Intent intent) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        Log.d(TAG, "newActivity cl:" + cl + " className:" + className);
        try {
            // 有注册的Activity，只是为了欺骗AMS，但是实际上并没有类文件存在！
            cl.loadClass(className);
        } catch (ClassNotFoundException e) {
            ComponentName componentName = mPluginManager.resolveIntent(intent);
            Activity activity = mBase.newActivity(cl, componentName.getClassName(), intent);
            activity.setIntent(intent);

            return activity;
        }

        return mBase.newActivity(cl, className, intent);
    }

}
