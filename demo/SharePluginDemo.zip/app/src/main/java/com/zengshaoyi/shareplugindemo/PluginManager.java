package com.zengshaoyi.shareplugindemo;

import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/17 21:04
 */
public class PluginManager {

    private static class SingletonHolder {
        private static PluginManager sInstance = new PluginManager();
    }

    private PluginManager() {
    }

    public static PluginManager getInstance() {
        return SingletonHolder.sInstance;
    }

    public void init(Context appContext) {
        // Hook Instrumentation
        Instrumentation base = ReflectUtil.getInstrumentation(appContext);
        MyInstrumentation myInstrumentation = new MyInstrumentation(base, this);
        ReflectUtil.setInstrumentation(ReflectUtil.getActivityThread(appContext), myInstrumentation);
    }

    public void makeIntentIfNeed(Intent intent) {
        ComponentName componentName = intent.getComponent();
        String targetPackage = componentName.getPackageName();
        String targetClassName = componentName.getClassName();

        if ("com.zengshaoyi.shareplugindemo.TargetActivity".equals(targetClassName)) {
            // 保存目标数据
            intent.putExtra(Constants.KEY_IS_PLUGIN, true);
            intent.putExtra(Constants.KEY_TARGET_ACTIVITY, targetClassName);
            intent.putExtra(Constants.KEY_TARGET_PACKAGE, targetPackage);

            // 换成stubActivity
            String stubPackage = "com.zengshaoyi.shareplugindemo";
            String stubClassName = "com.zengshaoyi.shareplugindemo.StubActivity";
            ComponentName stubComponent = new ComponentName(stubPackage, stubClassName);
            intent.setComponent(stubComponent);
        }
    }

    public ComponentName resolveIntent(Intent intent) {
        return new ComponentName(intent.getStringExtra(Constants.KEY_TARGET_PACKAGE),
                intent.getStringExtra(Constants.KEY_TARGET_ACTIVITY));
    }

}
