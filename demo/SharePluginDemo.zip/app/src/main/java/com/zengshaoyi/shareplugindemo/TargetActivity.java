package com.zengshaoyi.shareplugindemo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/17 21:04
 */
public class TargetActivity extends Activity {

    public static void startActivity(Context pContext){
        Intent intent = new Intent(pContext, TargetActivity.class);
        pContext.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target);
    }
}
