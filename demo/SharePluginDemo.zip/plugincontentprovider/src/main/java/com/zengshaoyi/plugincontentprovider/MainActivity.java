package com.zengshaoyi.plugincontentprovider;

import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mButton = findViewById(R.id.button);
        mButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == mButton){
            queryBookProvider();
        }
    }

    private void queryBookProvider(){
        ContentResolver resolver = getContentResolver();
        Uri bookUri = Uri.parse("content://com.zengshaoyi.plugindemo.book.provider/book");
        Cursor cursor = resolver.query(bookUri, null, null, null, null);
        while (cursor.moveToNext()) {
            int bookId = cursor.getInt(0);
            String bookName = cursor.getString(1);
            Log.d(TAG, "query book:" + bookId + ", " + bookName);
        }
        cursor.close();
    }
}
