package com.zengshaoyi.pluginservice.service;

import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.util.Log;

import com.zengshaoyi.pluginservice.PluginManager;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/19 00:43
 */
public class ProxyService extends Service{

    private static final String TAG = "ProxyService";

    public static final String EXTRA_TARGET = "target";
    public static final String EXTRA_COMMAND = "command";

    public static final int EXTRA_COMMAND_START_SERVICE = 1;
    public static final int EXTRA_COMMAND_STOP_SERVICE = 2;


    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Intent target = intent.getParcelableExtra(EXTRA_TARGET);
        int command = intent.getIntExtra(EXTRA_COMMAND, 0);

        switch (command){
            case EXTRA_COMMAND_START_SERVICE:
                try {
                    Service service;
                    if (!PluginManager.getInstance().isServiceAvailable(target.getComponent().getClassName())) {
                        // service还不存在, 先创建
                        ServiceInfo info = PluginManager.getInstance().resolveService(target);
                        service = PluginManager.getInstance().createPluginService(info);
                    }else{
                        service = PluginManager.getInstance().getCacheService(target.getComponent().getClassName());
                    }
                    service.onStartCommand(target,0, startId);

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case EXTRA_COMMAND_STOP_SERVICE:
                Service service = PluginManager.getInstance().forgetService(target.getComponent().getClassName());
                Log.d(TAG, "stopService :"+service);
                if (null != service) {
                    try {
                        // 调用插件服务的 onDestory 的方法
                        service.onDestroy();
                    } catch (Exception e) {
                        Log.e(TAG, "Unable to stop service " + service + ": " + e.toString());
                    }
                } else {
                    Log.i(TAG, intent.getComponent().getClassName() + " not found");
                }
                break;
        }

        return START_STICKY;
    }

}
