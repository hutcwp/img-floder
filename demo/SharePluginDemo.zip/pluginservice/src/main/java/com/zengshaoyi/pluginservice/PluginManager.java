package com.zengshaoyi.pluginservice;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageParser;
import android.content.pm.ServiceInfo;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import com.zengshaoyi.pluginservice.delegate.ActivityManagerProxy;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import dalvik.system.DexClassLoader;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/17 21:04
 */
public class PluginManager {

    private static final String TAG = "PluginManager";

    private File mNativeLibDir;

    private Map<String, ServiceInfo> mServiceInfos;

    private Map<String, Service> mServices = new HashMap<>();

    private Context mHostContext;

    private static class SingletonHolder {
        private static PluginManager sInstance = new PluginManager();
    }

    private PluginManager() {
    }

    public static PluginManager getInstance() {
        return SingletonHolder.sInstance;
    }

    public void init(Context appContext) {
        Log.d(TAG, "init");
        Systems.setContext(appContext);
        mHostContext = appContext;
        FileUtils.copyAssets2InternalFiles(appContext, "plugindemo.apk");
        File dir = appContext.getFilesDir();
        File pluginAPK = new File(dir, "plugindemo.apk");
        Log.d(TAG, "is file exsists:"+pluginAPK.exists());
        this.mNativeLibDir = appContext.getDir(Constants.NATIVE_DIR, Context.MODE_PRIVATE);
        loadApk(appContext, pluginAPK, mNativeLibDir, appContext.getClassLoader());
        // 解析 plugin
        try {
            PackageParser.Package pluginPackage = PackageParserCompat.parsePackage(appContext, pluginAPK, PackageParser.PARSE_MUST_BE_APK);
            // Cache services
            Map<String, ServiceInfo> serviceInfos = new HashMap<String, ServiceInfo>();
            for (PackageParser.Service service : pluginPackage.services) {
                serviceInfos.put(service.getComponentName().getClassName(), service.info);
            }
            this.mServiceInfos = Collections.unmodifiableMap(serviceInfos);

        } catch (PackageParser.PackageParserException e) {
            e.printStackTrace();
        }

        hookAMS();
        // 资源处理
        createResources(appContext, pluginAPK);
    }

    private static Resources createResources(Context context, File apk) {
        Resources resources = ResourcesManager.createResources(context, apk.getAbsolutePath());
        ResourcesManager.hookResources(context, resources);
        return resources;
    }

    private static AssetManager createAssetManager(Context context, File apk) {
        try {
            AssetManager am = AssetManager.class.newInstance();
            ReflectUtil.invoke(AssetManager.class, am, "addAssetPath", apk.getAbsolutePath());
            return am;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean isPluginService(Intent intent){
        String targetService = intent.getComponent().getClassName();
        return mServiceInfos.containsKey(targetService);
    }

    public void stopService(Intent intent){
         mHostContext.startService(intent);
    }



    private static void hookAMS()  {
        try {
            Class<?> activityManagerNativeClass = Class.forName("android.app.ActivityManagerNative");

            Field gDefaultField = activityManagerNativeClass.getDeclaredField("gDefault");
            gDefaultField.setAccessible(true);

            Object gDefault = gDefaultField.get(null);

            // gDefault是一个 android.util.Singleton对象; 我们取出这个单例里面的字段
            Class<?> singleton = Class.forName("android.util.Singleton");
            Field mInstanceField = singleton.getDeclaredField("mInstance");
            mInstanceField.setAccessible(true);

            // ActivityManagerNative 的gDefault对象里面原始的 IActivityManager对象
            Object rawIActivityManager = mInstanceField.get(gDefault);

            // 创建一个这个对象的代理对象, 然后替换这个字段, 让我们的代理对象帮忙干活
            Class<?> iActivityManagerInterface = Class.forName("android.app.IActivityManager");
            Object proxy = Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(),
                    new Class<?>[]{iActivityManagerInterface}, new ActivityManagerProxy(rawIActivityManager));
            mInstanceField.set(gDefault, proxy);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static ClassLoader loadApk(Context context, File apk, File libsDir, ClassLoader parent) {
        Log.d(TAG, "loadApk parent:"+parent);

        File dexOutputDir = context.getDir(Constants.OPTIMIZE_DIR, Context.MODE_PRIVATE);
        String dexOutputPath = dexOutputDir.getAbsolutePath();
        // 因为传入的父类 ClassLoader ，而且通过插入的方式传递到了parent类中，其实一直只会用到parent类处理类
        DexClassLoader loader = new DexClassLoader(apk.getAbsolutePath(), dexOutputPath, libsDir.getAbsolutePath(), parent);

        if (Constants.COMBINE_CLASSLOADER) {
            try {
                DexUtil.insertDex(loader);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return loader;
    }

    public ServiceInfo resolveService(Intent intent){
        return mServiceInfos.get(intent.getComponent().getClassName());
    }

    /**
     * 通过ActivityThread的handleCreateService方法创建出Service对象
     * @param serviceInfo 插件的ServiceInfo
     * @throws Exception
     */
    public Service createPluginService(ServiceInfo serviceInfo) throws Exception {
        IBinder token = new Binder();

        // 创建CreateServiceData对象, 用来传递给ActivityThread的handleCreateService 当作参数
        Class<?> createServiceDataClass = Class.forName("android.app.ActivityThread$CreateServiceData");
        Constructor<?> constructor  = createServiceDataClass.getDeclaredConstructor();
        constructor.setAccessible(true);
        Object createServiceData = constructor.newInstance();

        // 写入我们创建的createServiceData的token字段, ActivityThread的handleCreateService用这个作为key存储Service
        Field tokenField = createServiceDataClass.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(createServiceData, token);

        // 写入info对象
        // 这个修改是为了loadClass的时候, LoadedApk会是主程序的ClassLoader, 我们选择Hook BaseDexClassLoader的方式加载插件
        serviceInfo.applicationInfo.packageName = Systems.getContext().getPackageName();
        Field infoField = createServiceDataClass.getDeclaredField("info");
        infoField.setAccessible(true);
        infoField.set(createServiceData, serviceInfo);

        // 写入compatInfo字段
        // 获取默认的compatibility配置
        Class<?> compatibilityClass = Class.forName("android.content.res.CompatibilityInfo");
        Field defaultCompatibilityField = compatibilityClass.getDeclaredField("DEFAULT_COMPATIBILITY_INFO");
        Object defaultCompatibility = defaultCompatibilityField.get(null);
        Field compatInfoField = createServiceDataClass.getDeclaredField("compatInfo");
        compatInfoField.setAccessible(true);
        compatInfoField.set(createServiceData, defaultCompatibility);

        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Method currentActivityThreadMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
        Object currentActivityThread = currentActivityThreadMethod.invoke(null);

        // private void handleCreateService(CreateServiceData data) {
        Method handleCreateServiceMethod = activityThreadClass.getDeclaredMethod("handleCreateService", createServiceDataClass);
        handleCreateServiceMethod.setAccessible(true);

        handleCreateServiceMethod.invoke(currentActivityThread, createServiceData);

        // handleCreateService创建出来的Service对象并没有返回, 而是存储在ActivityThread的mServices字段里面, 这里我们手动把它取出来
        Field mServicesField = activityThreadClass.getDeclaredField("mServices");
        mServicesField.setAccessible(true);
        Map activityThreadServices = (Map) mServicesField.get(currentActivityThread);
        Service service = (Service) activityThreadServices.get(token);

        // 获取到之后, 移除这个service, 我们只是借花献佛
        activityThreadServices.remove(token);

        // 将此Service存储起来
        rememberService(serviceInfo.name, service);

        return service;
    }

    public void rememberService(String serviceName, Service service) {
        synchronized (this.mServices) {
            this.mServices.put(serviceName, service);
        }
    }

    public Service forgetService(String serviceName) {
        synchronized (this.mServices) {
            Service service = this.mServices.remove(serviceName);
            return service;
        }
    }

    public boolean isServiceAvailable(String serviceName) {
        return this.mServices.containsKey(serviceName);
    }

    public Service getCacheService(String serviceName){
        return this.mServices.get(serviceName);
    }

}
