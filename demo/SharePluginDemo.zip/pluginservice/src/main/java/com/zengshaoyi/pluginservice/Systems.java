package com.zengshaoyi.pluginservice;

import android.content.Context;

/**
 * @author Zengshaoyi
 * @version 1.0 <p><strong>Features draft description.主要功能介绍</strong></p>
 * @since 2018/9/18 10:43
 */
public class Systems {

    private static Context sApplicationContext;

    public static Context getContext() {
        return sApplicationContext;
    }

    public static void setContext(Context applicationContext) {
        sApplicationContext = applicationContext;
    }
}
