/*
 * Copyright (C) 2017 Beijing Didi Infinity Technology and Development Co.,Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.zengshaoyi.pluginservice.delegate;

import android.content.ComponentName;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;

import com.zengshaoyi.pluginservice.PluginManager;
import com.zengshaoyi.pluginservice.Systems;
import com.zengshaoyi.pluginservice.service.ProxyService;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * @author johnsonlee
 */
public class ActivityManagerProxy implements InvocationHandler {

    private static final String TAG = "ActivityManagerProxy";

    Object mBase;

    public ActivityManagerProxy(Object base) {
        mBase = base;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        if ("startService".equals(method.getName())) {
            // 找到参数里面的第一个Intent 对象
            Pair<Integer, Intent> integerIntentPair = foundFirstIntentOfArgs(args);
            Intent raw = integerIntentPair.second;

            // 判断是不是要启动插件 Service
            if(PluginManager.getInstance().isPluginService(raw)){
                Intent newIntent = new Intent();
                // 代理Service的包名, 也就是我们自己的包名
                String hostPackage = Systems.getContext().getPackageName();

                // 这里我们把启动的Service替换为ProxyService, 让ProxyService接收生命周期回调
                ComponentName componentName = new ComponentName(hostPackage, ProxyService.class.getName());
                newIntent.setComponent(componentName);

                // 把我们原始要启动的TargetService先存起来
                newIntent.putExtra(ProxyService.EXTRA_TARGET, raw);
                newIntent.putExtra(ProxyService.EXTRA_COMMAND, ProxyService.EXTRA_COMMAND_START_SERVICE);
                // 替换掉Intent, 达到欺骗AMS的目的
                args[integerIntentPair.first] = newIntent;
                Log.v(TAG, "hook method startService success");
            }
            return method.invoke(mBase, args);

        }

        if ("stopService".equals(method.getName())) {
            Pair<Integer, Intent> integerIntentPair = foundFirstIntentOfArgs(args);
            Intent raw = integerIntentPair.second;
            if (PluginManager.getInstance().isPluginService(raw)) {
                // 插件的intent才做hook
                Intent newIntent = new Intent();
                String hostPackage = Systems.getContext().getPackageName();
                ComponentName componentName = new ComponentName(hostPackage, ProxyService.class.getName());
                newIntent.setComponent(componentName);

                // 把我们原始要启动的TargetService先存起来
                newIntent.putExtra(ProxyService.EXTRA_TARGET, raw);
                newIntent.putExtra(ProxyService.EXTRA_COMMAND, ProxyService.EXTRA_COMMAND_STOP_SERVICE);
                // 替换掉Intent, 达到欺骗AMS的目的
                args[integerIntentPair.first] = newIntent;
                PluginManager.getInstance().stopService(newIntent);
                Log.v(TAG, "hook method stopService success");
                return 1;
            }
        }

        return method.invoke(mBase, args);
    }

    private Pair<Integer, Intent> foundFirstIntentOfArgs(Object... args) {
        int index = 0;

        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof Intent) {
                index = i;
                break;
            }
        }
        return Pair.create(index, (Intent) args[index]);
    }

}
