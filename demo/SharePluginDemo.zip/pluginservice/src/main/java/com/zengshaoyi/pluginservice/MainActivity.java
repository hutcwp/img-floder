package com.zengshaoyi.pluginservice;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

    Button mStartBtn;

    Button mStopBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mStartBtn = findViewById(R.id.button);
        mStartBtn.setOnClickListener(this);

        mStopBtn = findViewById(R.id.button2);
        mStopBtn.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        if(v == mStartBtn){
            startPluginService();
        }else if(v == mStopBtn){
            stopPluginService();
        }
    }

    private void startPluginService(){
        Intent intent = new Intent();
        String pluginPkg = "com.zengshaoyi.plugindemo";
        String pluginService = "com.zengshaoyi.plugindemo.service.PluginService";
        intent.setComponent(new ComponentName(pluginPkg, pluginService));
        startService(intent);
    }

    private void stopPluginService(){
        Intent intent = new Intent();
        String pluginPkg = "com.zengshaoyi.plugindemo";
        String pluginService = "com.zengshaoyi.plugindemo.service.PluginService";
        intent.setComponent(new ComponentName(pluginPkg, pluginService));
        stopService(intent);
    }
}
